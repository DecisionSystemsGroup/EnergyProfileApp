jQuery.get('testtest.txt', function(data) {
    var myvar = data;
});